<!DOCTYPE html>
<html>
<head>
    <title>Quiquiz</title>
    <link rel="stylesheet" type="text/css" href="css/index.min.css">
</head>
<body>
    <div class="mainWrapper">
        <h1>
            Quiquiz
        </h1>

        <form method="get" action="new.php">
            <input type="submit" class="button" name="submit" value="New Quiquiz" />
        </form>
    </div>
</body>
</html>
